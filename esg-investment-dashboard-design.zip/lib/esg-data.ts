export const company = {
  name: "Tesla Inc.",
  ticker: "TSLA",
  industry: "Automotive",
  country: "United States",
  type: "Public Company",
}

export const kpis = {
  esgScore: 48,
  momentumScore: 82,
  aiConfidence: 87,
}

export const trendData = [
  { month: "Jan", esg: 39, momentum: 58 },
  { month: "Feb", esg: 41, momentum: 64 },
  { month: "Mar", esg: 43, momentum: 69 },
  { month: "Apr", esg: 44, momentum: 74 },
  { month: "May", esg: 46, momentum: 79 },
  { month: "Jun", esg: 48, momentum: 82 },
]

export const pillars = [
  { label: "Environmental", value: 72, improving: true },
  { label: "Social", value: 61, improving: true },
  { label: "Governance", value: 68, improving: false },
  { label: "Innovation & Digital", value: 81, improving: true },
]

export const overallPillarScore = 74

export type EvidenceSignal = {
  label: string
  value: string
  positive: boolean
  icon: "sentiment" | "hiring" | "patent" | "renewable" | "carbon" | "report"
}

export const evidenceSignals: EvidenceSignal[] = [
  { label: "Positive News Sentiment", value: "82%", positive: true, icon: "sentiment" },
  { label: "ESG Hiring Growth", value: "+38%", positive: true, icon: "hiring" },
  { label: "Green Patent Filings", value: "+24%", positive: true, icon: "patent" },
  { label: "Renewable Energy Investment", value: "High", positive: true, icon: "renewable" },
  { label: "Carbon Emissions Reduction", value: "-12%", positive: true, icon: "carbon" },
  { label: "ESG Report Improvement", value: "Strong", positive: true, icon: "report" },
]

export const summaryHighlights = [
  "Positive sustainability news",
  "Increased green hiring",
  "Patent growth",
  "Reduced controversies",
  "Improved governance",
]

export type Category = "Future Leader" | "Hidden Winner" | "Overrated Leader" | "Value Trap"

export type WatchRow = {
  company: string
  ticker: string
  esg: number
  momentum: number
  trend: "up" | "down" | "flat"
  category: Category
}

export const watchlist: WatchRow[] = [
  { company: "Tesla", ticker: "TSLA", esg: 48, momentum: 82, trend: "up", category: "Future Leader" },
  { company: "Microsoft", ticker: "MSFT", esg: 84, momentum: 79, trend: "up", category: "Future Leader" },
  { company: "Apple", ticker: "AAPL", esg: 80, momentum: 41, trend: "down", category: "Overrated Leader" },
  { company: "DBS", ticker: "DBS", esg: 44, momentum: 76, trend: "up", category: "Hidden Winner" },
  { company: "NVIDIA", ticker: "NVDA", esg: 39, momentum: 33, trend: "flat", category: "Value Trap" },
]

export type Alert = {
  company: string
  message: string
  time: string
  tone: "positive" | "neutral" | "info"
}

export const alerts: Alert[] = [
  { company: "Tesla", message: "Released a new sustainability report.", time: "2h ago", tone: "positive" },
  { company: "Apple", message: "Announced a carbon-neutral initiative.", time: "5h ago", tone: "info" },
  { company: "NVIDIA", message: "Increased ESG hiring across teams.", time: "8h ago", tone: "positive" },
  { company: "Microsoft", message: "Received a positive governance rating.", time: "1d ago", tone: "neutral" },
]
